import { musicMenus } from "./music/index.js";
export * from "./manager/manageMenu.js";

export const menus = {
    music: musicMenus
};